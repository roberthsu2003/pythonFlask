from app import creatApp

app = creatApp()
if __name__ == "__main__":
    app.debug = True
    app.run()